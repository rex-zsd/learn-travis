echo "hello world!"
scp package.json rex@45.32.48.52:/home/rex
