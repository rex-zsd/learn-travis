echo "hello world!"
scp -o StrictHostKeyChecking=no package.json rex@45.32.48.52:/home/rex
